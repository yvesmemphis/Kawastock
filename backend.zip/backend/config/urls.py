"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api-auth/', include('rest_framework.urls')),
    path('api/v1/', include('catalog.urls')),
    path('api/v1/', include('inventory.urls')),
    path('api/v1/', include('purchases.urls')),
    path('api/v1/', include('sales.urls')),
    path('api/v1/', include('suppliers.urls')),
    path('api/v1/', include('reports.urls')),     
    path('api/v1/', include('accounts.urls')),     
    path('api/v1/', include('shops.urls')),   
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),                        # la description brute
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='docs'),       # la jolie page 
    ]

