from django.db import models

# Create your models here.
import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True)
       # "Pour te connecter, donne ton EMAIL (pas ton nom d'utilisateur)."
    USERNAME_FIELD = "email"
    # Obligatoire pour createsuperuser : les autres champs à demander en plus de l'email.
    REQUIRED_FIELDS = ["username"]